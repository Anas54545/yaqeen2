import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:adhan_dart/adhan_dart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

const green = Color(0xFF0B6B4A);
const darkGreen = Color(0xFF063B2B);
const gold = Color(0xFFC9A227);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tz.initializeTimeZones();
  await NotificationService.instance.init();
  runApp(const YaqeenApp());
}

class YaqeenApp extends StatelessWidget {
  const YaqeenApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'يقين',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7F8F5),
        fontFamily: 'sans',
        appBarTheme: const AppBarTheme(centerTitle: true, backgroundColor: Colors.transparent),
        cardTheme: CardThemeData(elevation: 0, margin: EdgeInsets.zero, color: Colors.white),
      ),
      home: const HomeShell(),
    );
  }
}

class PrayerItem {
  final String keyName;
  final String arabic;
  final DateTime time;
  final IconData icon;
  PrayerItem(this.keyName, this.arabic, this.time, this.icon);
}

class PrayerService {
  static Future<Position?> getLocation() async {
    if (!await Geolocator.isLocationServiceEnabled()) return null;
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return null;
    return Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.medium));
  }

  static PrayerTimes calculate(double lat, double lng, DateTime date) {
    final params = CalculationMethodParameters.egyptian()
      ..madhab = Madhab.shafi
      ..rounding = Rounding.nearest;
    return PrayerTimes(
      coordinates: Coordinates(lat, lng),
      date: date,
      calculationParameters: params,
      precision: false,
    );
  }

  static List<PrayerItem> items(PrayerTimes p) => [
        PrayerItem('fajr', 'الفجر', p.fajr, Icons.nightlight_round),
        PrayerItem('dhuhr', 'الظهر', p.dhuhr, Icons.wb_sunny_outlined),
        PrayerItem('asr', 'العصر', p.asr, Icons.wb_twilight),
        PrayerItem('maghrib', 'المغرب', p.maghrib, Icons.wb_twilight),
        PrayerItem('isha', 'العشاء', p.isha, Icons.nights_stay_outlined),
      ];
}

class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();
  final plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    final zone = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(zone.identifier));
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await plugin.initialize(settings: settings);
    final androidImpl = plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidImpl?.requestNotificationsPermission();
    await androidImpl?.requestExactAlarmsPermission();
    const channel = AndroidNotificationChannel(
      'yaqeen_prayer',
      'مواقيت الصلاة',
      description: 'تنبيهات الصلاة في تطبيق يقين',
      importance: Importance.max,
      playSound: true,
      enableVibration: true,
    );
    await androidImpl?.createNotificationChannel(channel);
  }

  Future<void> schedulePrayerNotifications({required double lat, required double lng}) async {
    await plugin.cancelAll();
    for (int day = 0; day < 7; day++) {
      final date = DateTime.now().add(Duration(days: day));
      final prayers = PrayerService.items(PrayerService.calculate(lat, lng, date));
      for (int i = 0; i < prayers.length; i++) {
        final local = tz.TZDateTime.from(prayers[i].time, tz.local);
        if (local.isBefore(tz.TZDateTime.now(tz.local))) continue;
        await plugin.zonedSchedule(
          id: day * 10 + i,
          title: 'حان الآن وقت ${prayers[i].arabic}',
          body: 'الله أكبر — الصلاة خير من النوم، حي على الصلاة',
          scheduledDate: local,
          notificationDetails: const NotificationDetails(
            android: AndroidNotificationDetails(
              'yaqeen_prayer',
              'مواقيت الصلاة',
              channelDescription: 'تنبيهات الصلاة في تطبيق يقين',
              importance: Importance.max,
              priority: Priority.max,
              playSound: true,
              enableVibration: true,
              category: AndroidNotificationCategory.alarm,
            ),
          ),
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          payload: prayers[i].keyName,
        );
      }
    }
  }
}

class Store {
  static Future<SharedPreferences> get prefs => SharedPreferences.getInstance();

  static Future<void> setPrayer(String date, String prayer, bool value) async {
    final p = await prefs;
    await p.setBool('prayer:$date:$prayer', value);
  }

  static Future<bool> getPrayer(String date, String prayer) async {
    final p = await prefs;
    return p.getBool('prayer:$date:$prayer') ?? false;
  }

  static Future<void> setHabit(String date, String habit, bool value) async {
    final p = await prefs;
    await p.setBool('habit:$date:$habit', value);
  }

  static Future<bool> getHabit(String date, String habit) async {
    final p = await prefs;
    return p.getBool('habit:$date:$habit') ?? false;
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  Position? position;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadLocation();
  }

  Future<void> _loadLocation() async {
    final p = await PrayerService.getLocation();
    if (p != null) {
      position = p;
      await NotificationService.instance.schedulePrayerNotifications(lat: p.latitude, lng: p.longitude);
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      Dashboard(position: position, onRefresh: _loadLocation),
      const QuranPage(),
      const HadithPage(),
      const AdhkarPage(),
      const TrackerPage(),
    ];
    return Scaffold(
      body: SafeArea(child: loading ? const Center(child: CircularProgressIndicator()) : pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'القرآن'),
          NavigationDestination(icon: Icon(Icons.auto_stories_outlined), selectedIcon: Icon(Icons.auto_stories), label: 'الحديث'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'الأذكار'),
          NavigationDestination(icon: Icon(Icons.checklist_outlined), selectedIcon: Icon(Icons.checklist), label: 'المتابعة'),
        ],
      ),
    );
  }
}

class Dashboard extends StatefulWidget {
  final Position? position;
  final Future<void> Function() onRefresh;
  const Dashboard({super.key, required this.position, required this.onRefresh});
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  late DateTime now;
  Timer? timer;
  @override
  void initState() {
    super.initState();
    now = DateTime.now();
    timer = Timer.periodic(const Duration(seconds: 30), (_) => setState(() => now = DateTime.now()));
  }
  @override
  void dispose() { timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (widget.position == null) {
      return Center(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.location_off_outlined, size: 56, color: green),
          const SizedBox(height: 12),
          const Text('فعّل الموقع لحساب مواقيت الصلاة بدقة.', textAlign: TextAlign.center),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: widget.onRefresh, icon: const Icon(Icons.location_on), label: const Text('تفعيل الموقع')),
        ]),
      ));
    }
    final pt = PrayerService.calculate(widget.position!.latitude, widget.position!.longitude, now);
    final items = PrayerService.items(pt);
    final next = items.firstWhere((x) => x.time.isAfter(now), orElse: () => items.first);
    return RefreshIndicator(
      onRefresh: widget.onRefresh,
      child: ListView(padding: const EdgeInsets.fromLTRB(18, 10, 18, 24), children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('يقين', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: darkGreen)),
            Text('رفيقك إلى الطمأنينة', style: TextStyle(color: Colors.black54)),
          ]),
          IconButton(onPressed: widget.onRefresh, icon: const Icon(Icons.my_location)),
        ]),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: darkGreen, borderRadius: BorderRadius.circular(26)),
          child: Column(children: [
            Text(DateFormat('EEEE، d MMMM', 'ar').format(now), style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 12),
            const Text('الصلاة القادمة', style: TextStyle(color: Colors.white70)),
            Text(next.arabic, style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
            Text(DateFormat('hh:mm a').format(next.time), style: const TextStyle(color: gold, fontSize: 32, fontWeight: FontWeight.w800)),
          ]),
        ),
        const SizedBox(height: 16),
        const Text('مواقيت اليوم', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        ...items.map((p) => _PrayerTile(item: p, active: p.keyName == next.keyName)),
        const SizedBox(height: 18),
        const QuickCard(),
      ]),
    );
  }
}

class _PrayerTile extends StatelessWidget {
  final PrayerItem item; final bool active;
  const _PrayerTile({required this.item, required this.active});
  @override
  Widget build(BuildContext context) => Card(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: active ? green : Colors.transparent, width: active ? 1.5 : 0)),
    child: ListTile(
      leading: CircleAvatar(backgroundColor: active ? green : const Color(0xFFE9F2EE), foregroundColor: active ? Colors.white : green, child: Icon(item.icon)),
      title: Text(item.arabic, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(active ? 'الصلاة القادمة' : 'وقت الصلاة'),
      trailing: Text(DateFormat('hh:mm a').format(item.time), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
    ),
  );
}

class QuickCard extends StatelessWidget {
  const QuickCard({super.key});
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [
      const CircleAvatar(radius: 24, backgroundColor: Color(0xFFE9F2EE), child: Icon(Icons.format_quote, color: green)),
      const SizedBox(width: 14),
      Expanded(child: Text('«ألا بذكر الله تطمئن القلوب»\nالرعد: 28', style: Theme.of(context).textTheme.titleMedium)),
    ])),
  );
}

class QuranPage extends StatefulWidget { const QuranPage({super.key}); @override State<QuranPage> createState() => _QuranPageState(); }
class _QuranPageState extends State<QuranPage> {
  List<dynamic>? ayahs; bool loading = true; String? error;
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    try {
      final r = await http.get(Uri.parse('https://api.alquran.cloud/v1/surah/1/quran-uthmani-quran-academy'));
      if (r.statusCode != 200) throw Exception('network');
      ayahs = (jsonDecode(r.body)['data']['ayahs'] as List);
    } catch (_) { error = 'تعذر تحميل القرآن. تحقق من الإنترنت.'; }
    if (mounted) setState(() => loading = false);
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('القرآن الكريم')),
    body: loading ? const Center(child: CircularProgressIndicator()) : error != null ? Center(child: Text(error!)) : ListView.builder(
      padding: const EdgeInsets.all(18), itemCount: ayahs!.length,
      itemBuilder: (_, i) { final a = ayahs![i]; return Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(a['text'], textAlign: TextAlign.right, textDirection: ui.TextDirection.rtl, style: const TextStyle(fontSize: 25, height: 2.0)),
        const SizedBox(height: 10), Text('﴿ ${a['numberInSurah']} ﴾', textAlign: TextAlign.center, style: const TextStyle(color: green, fontWeight: FontWeight.bold)),
      ]))); },
    ),
  );
}

class HadithPage extends StatefulWidget { const HadithPage({super.key}); @override State<HadithPage> createState() => _HadithPageState(); }
class _HadithPageState extends State<HadithPage> {
  String book = 'bukhari'; List<dynamic> hadiths = []; bool loading = true; String? error;
  final books = const {'bukhari':'صحيح البخاري', 'muslim':'صحيح مسلم'};
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final r = await http.get(Uri.parse('https://api.hadith.gading.dev/books/$book?range=1-50'));
      if (r.statusCode != 200) throw Exception();
      hadiths = jsonDecode(r.body)['data']['hadiths'] as List;
    } catch (_) { error = 'تعذر تحميل الأحاديث. تحقق من الإنترنت.'; }
    if (mounted) setState(() => loading = false);
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الأحاديث الصحيحة')),
    body: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 8), child: SegmentedButton<String>(segments: books.entries.map((e) => ButtonSegment(value: e.key, label: Text(e.value))).toList(), selected: {book}, onSelectionChanged: (v) { book = v.first; load(); setState(() {}); })),
      Expanded(child: loading ? const Center(child: CircularProgressIndicator()) : error != null ? Center(child: Text(error!)) : ListView.builder(padding: const EdgeInsets.all(16), itemCount: hadiths.length, itemBuilder: (_, i) {
        final h = hadiths[i]; return Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('حديث رقم ${h['number']}', style: const TextStyle(color: green, fontWeight: FontWeight.bold)), const SizedBox(height: 10),
          Text(h['arab'], textDirection: ui.TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 20, height: 1.8)),
        ]))); }))
    ]),
  );
}

class AdhkarPage extends StatefulWidget { const AdhkarPage({super.key}); @override State<AdhkarPage> createState() => _AdhkarPageState(); }
class _AdhkarPageState extends State<AdhkarPage> {
  final items = const [
    ['سبحان الله', '100 مرة'], ['الحمد لله', '100 مرة'], ['الله أكبر', '100 مرة'],
    ['أستغفر الله', '100 مرة'], ['لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير', '100 مرة'],
    ['اللهم صل وسلم على نبينا محمد', '100 مرة'],
  ];
  final Map<int,int> counts = {};
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('الأذكار')), body: ListView.builder(padding: const EdgeInsets.all(16), itemCount: items.length, itemBuilder: (_, i) {
    final c = counts[i] ?? 0; final target = int.tryParse(items[i][1].split(' ').first) ?? 100;
    return Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
      Text(items[i][0], textAlign: TextAlign.center, textDirection: ui.TextDirection.rtl, style: const TextStyle(fontSize: 21, height: 1.7, fontWeight: FontWeight.w600)),
      const SizedBox(height: 12), Text('${items[i][1]} — $c / $target'), const SizedBox(height: 10),
      FilledButton.icon(onPressed: c >= target ? null : () => setState(() => counts[i] = c + 1), icon: const Icon(Icons.touch_app), label: const Text('سبّح')),
    ])));
  }));
}

class TrackerPage extends StatefulWidget { const TrackerPage({super.key}); @override State<TrackerPage> createState() => _TrackerPageState(); }
class _TrackerPageState extends State<TrackerPage> {
  DateTime selected = DateTime.now();
  final prayers = const ['الفجر','الظهر','العصر','المغرب','العشاء'];
  final habits = const ['الأذكار','قراءة القرآن'];
  String keyDate(DateTime d) => DateFormat('yyyy-MM-dd').format(d);
  Future<void> togglePrayer(String p) async { final d=keyDate(selected); final old=await Store.getPrayer(d,p); await Store.setPrayer(d,p,!old); setState(() {}); }
  Future<void> toggleHabit(String h) async { final d=keyDate(selected); final old=await Store.getHabit(d,h); await Store.setHabit(d,h,!old); setState(() {}); }
  @override Widget build(BuildContext context) {
    final days = List.generate(7, (i) => DateTime.now().subtract(Duration(days: 6-i)));
    return Scaffold(appBar: AppBar(title: const Text('متابعة الأسبوع')), body: ListView(padding: const EdgeInsets.all(16), children: [
      SizedBox(height: 82, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: days.length, separatorBuilder: (_,__)=>const SizedBox(width:8), itemBuilder: (_,i){final d=days[i]; final sel=keyDate(d)==keyDate(selected); return ChoiceChip(label: Column(mainAxisSize: MainAxisSize.min, children:[Text(DateFormat('EEE','ar').format(d)),Text('${d.day}')]), selected: sel, onSelected: (_)=>setState(()=>selected=d));})),
      const SizedBox(height: 18), const Text('الصلوات', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)), const SizedBox(height:8),
      ...prayers.map((p)=>FutureBuilder<bool>(future: Store.getPrayer(keyDate(selected),p), builder:(_,s)=>CheckboxListTile(value:s.data??false,onChanged:(_)=>togglePrayer(p), title:Text(p), secondary:const Icon(Icons.mosque_outlined)))),
      const SizedBox(height: 10), const Text('العادات الإيمانية', style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      ...habits.map((h)=>FutureBuilder<bool>(future: Store.getHabit(keyDate(selected),h), builder:(_,s)=>CheckboxListTile(value:s.data??false,onChanged:(_)=>toggleHabit(h), title:Text(h), secondary:Icon(h=='الأذكار'?Icons.favorite_border:Icons.menu_book)))),
    ]));
  }
}
