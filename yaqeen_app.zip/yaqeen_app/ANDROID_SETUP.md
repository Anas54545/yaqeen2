# إعداد Android بعد `flutter create .`

افتح `android/app/src/main/AndroidManifest.xml` وأضف داخل `<manifest>` وقبل `<application>`:

```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
```

وتأكد أن `minSdk` مناسب للحزم الحديثة، وأن `compileSdk` حديث وفق نسخة Flutter المثبتة لديك.

## صوت الأذان

لو لديك ملف أذان مرخص، أنشئ:

`android/app/src/main/res/raw/adhan.mp3`

ثم في `lib/main.dart` غيّر `AndroidNotificationDetails` إلى:

```dart
sound: RawResourceAndroidNotificationSound('adhan'),
playSound: true,
```

ويُفضّل إنشاء Channel جديد باسم/ID مختلف عند تغيير الصوت، لأن Android يحتفظ بإعدادات الـ Channel القديمة.
